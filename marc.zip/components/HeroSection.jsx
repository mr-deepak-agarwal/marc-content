'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { ArrowRight, ChevronLeft, ChevronRight, ChevronDown } from 'lucide-react'
import Link from 'next/link'

const slides = [
  {
    id: 1,
    heading: 'Insights that sharpen growth bets.',
    description: 'Market, customer, and category intelligence to reduce risk and guide compounding growth.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1920&h=1080&fit=crop&q=90',
    ctaPrimary: { label: 'Explore Services', href: '/services/market-research' },
    ctaSecondary: { label: 'Learn More', href: '/services' },
  },
  {
    id: 2,
    heading: 'Numbers that guide growth.',
    description: 'Financial models, profitability analyses and focused financial diagnostics that translate data into clear growth priorities.',
    image: 'https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?w=1920&h=1080&fit=crop&q=90',
    ctaPrimary: { label: 'Explore Services', href: '/services/financial-analytics' },
    ctaSecondary: { label: 'Learn More', href: '/services' },
  },
  {
    id: 3,
    heading: 'M&A, designed for growth.',
    description: 'Strategic target identification, commercial diligence, and integration support — focused on value creation, not just deal completion.',
    image: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1920&h=1080&fit=crop&q=90',
    ctaPrimary: { label: 'Explore Services', href: '/services/mergers-acquisitions' },
    ctaSecondary: { label: 'Learn More', href: '/services' },
  },
  {
    id: 4,
    heading: 'Your outsourcing partner for global mandates.',
    description: 'International consultants trust MARC for on-ground research, due diligence, and advisory execution across India and emerging markets.',
    image: '/about/IMG_0359.JPG',
    ctaPrimary: { label: 'Partner With Us', href: '/contact' },
    ctaSecondary: { label: 'Our Capabilities', href: '/services' },
  },
]

const HeroSection = () => {
  const [current, setCurrent] = useState(0)
  const currentRef = useRef(0)

  const goTo = useCallback((index) => {
    currentRef.current = index
    setCurrent(index)
  }, [])

  const goPrev = useCallback(() => {
    goTo((currentRef.current - 1 + slides.length) % slides.length)
  }, [goTo])

  const goNext = useCallback(() => {
    goTo((currentRef.current + 1) % slides.length)
  }, [goTo])

  useEffect(() => {
    const id = setInterval(() => {
      goTo((currentRef.current + 1) % slides.length)
    }, 5000)
    return () => clearInterval(id)
  }, [goTo])

  const slide = slides[current]

  return (
    <section
      id="hero"
      data-testid="hero-section"
      className="relative w-full h-screen min-h-[600px] overflow-hidden"
    >
      {/* Background images */}
      {slides.map((s, i) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
            i === current ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img
            src={s.image}
            alt=""
            className="w-full h-full object-cover"
            style={{ filter: 'grayscale(100%)' }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/30 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
        </div>
      ))}

      {/* Arrows */}
      <button onClick={goPrev} aria-label="Previous slide" className="absolute left-4 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full bg-white/15 hover:bg-white/35 backdrop-blur-sm flex items-center justify-center transition-all duration-200">
        <ChevronLeft className="w-6 h-6 text-white" />
      </button>
      <button onClick={goNext} aria-label="Next slide" className="absolute right-4 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full bg-white/15 hover:bg-white/35 backdrop-blur-sm flex items-center justify-center transition-all duration-200">
        <ChevronRight className="w-6 h-6 text-white" />
      </button>

      {/* Content */}
      <div className="absolute inset-0 z-20 flex flex-col justify-between px-8 lg:px-20 max-w-7xl mx-auto left-0 right-0">

        {/* TOP — tagline */}
        <div className="pt-32">
          <div className="flex items-center gap-3 mb-1">
            <span className="w-8 h-[2px] bg-[#4E9141]" />
            <p className="text-[#4E9141] text-sm lg:text-base font-bold uppercase tracking-[0.2em]">
              No. 1 Advisor for Compounding Growth
            </p>
          </div>
          <p className="text-white/65 text-sm pl-11 max-w-lg leading-relaxed">
            Strategy and execution for Indian and global businesses that want to reimagine growth — year on year.
          </p>
        </div>

        {/* BOTTOM — slide content */}
        <div key={current} className="animate-slide-up pb-24 max-w-3xl">
          <h1 className="text-5xl lg:text-6xl xl:text-[4.5rem] font-bold text-white leading-[1.1] tracking-tight mb-5">
            {slide.heading}
          </h1>
          <p className="text-white/70 text-lg lg:text-xl font-light leading-relaxed mb-10 max-w-xl">
            {slide.description}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              href={slide.ctaPrimary.href}
              className="inline-flex items-center gap-2 px-8 py-4 bg-[#4E9141] text-white font-semibold rounded-md hover:bg-[#3e7433] transition-all duration-300 shadow-lg shadow-[#4E9141]/30 group"
            >
              {slide.ctaPrimary.label}
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href={slide.ctaSecondary.href}
              className="inline-flex items-center gap-2 px-8 py-4 bg-transparent text-white font-semibold border-2 border-white/40 rounded-md hover:border-white hover:bg-white/10 transition-all duration-300"
            >
              {slide.ctaSecondary.label}
            </Link>
          </div>
        </div>
      </div>

      {/* Dots + scroll */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-3">
        <ChevronDown className="w-5 h-5 text-white/50 animate-bounce" />
        <div className="flex items-center gap-3">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`transition-all duration-300 rounded-full ${
                i === current
                  ? 'w-10 h-2.5 bg-[#4E9141]'
                  : 'w-2.5 h-2.5 bg-white/40 hover:bg-white/70'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

export default HeroSection