'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Footer from '@/components/Footer'
import {
  caseStudies as detailedStudies,
  CASE_STUDY_INDUSTRIES,
  CASE_STUDY_SERVICES,
} from '@/data/caseStudies'
import { 
  ArrowRight, ArrowUpRight, Building2, TrendingUp, Award,
  Target, CheckCircle2, Lightbulb, Filter
} from 'lucide-react'

// Earlier PDF-based case studies (kept). New detailed pages live in data/caseStudies.js
const legacyStudies = [
  {
    id: 1,
    title: 'Profitability Analysis for Premium Jewellery Brand',
    client: 'Abharan Jewellers',
    industry: 'retail',
    service: 'Profitability Analysis',
    challenge: 'Identify key factors impacting store profitability and develop actionable improvement strategies across multiple retail locations.',
    solution: 'Comprehensive cost analysis, SKU-level profitability mapping, and operational efficiency audit.',
    outcomes: ['15% margin improvement', '20% cost reduction', 'Data-driven inventory'],
    image: 'https://images.pexels.com/photos/10983783/pexels-photo-10983783.jpeg?w=800',
    featured: true,
    pdfPath: '/case-studies/Case-Study-Abharan.pdf',
  },
  {
    id: 2,
    title: 'Revenue Optimization for Fine Dining Restaurant',
    client: 'Copper Leaf',
    industry: 'hospitality',
    service: 'Strategy Consulting',
    challenge: 'Optimize operations and enhance revenue streams for a premium dining establishment in a competitive market.',
    solution: 'Menu engineering, pricing strategy optimization, and customer experience enhancement program.',
    outcomes: ['20% revenue growth', '25% table turnover', 'Better retention'],
    image: 'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg?w=800',
    featured: true,
    pdfPath: '/case-studies/Case-Study-Copper-Leaf.pdf',
  },
  {
    id: 3,
    title: 'Turnaround Strategy for Beach Resort',
    client: 'Premium Hospitality',
    industry: 'hospitality',
    service: 'Profitability Analysis',
    challenge: 'Reverse declining profitability and optimize revenue streams across seasonal fluctuations.',
    solution: 'Seasonal pricing model, ancillary revenue development, and cost structure optimization.',
    outcomes: ['30% EBITDA boost', 'New revenue streams', 'Seasonal optimization'],
    image: 'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg?w=800',
    pdfPath: '/case-studies/Case-Study-PH.pdf',
  },
  {
    id: 4,
    title: 'Co-working Space Market Positioning',
    client: 'Vertex',
    industry: 'real-estate',
    service: 'Market Research',
    challenge: 'Define market positioning and growth strategy in an increasingly competitive co-working space market.',
    solution: 'Competitive benchmarking, customer segmentation, and pricing strategy development.',
    outcomes: ['Clear positioning', '40% occupancy up', 'Premium pricing'],
    image: 'https://images.pexels.com/photos/7070/space-desk-workspace-coworking.jpg?w=800',
    pdfPath: '/case-studies/Case-Study-Vertex.pdf',
  },
]

const LEGACY_SERVICE_IDS = {
  'Profitability Analysis': 'strategy',
  'Strategy Consulting': 'strategy',
  'Market Research': 'market-research',
}

const industryLabels = {
  hospitality: 'Hospitality',
  retail: 'Retail',
  'real-estate': 'Real Estate',
  ...CASE_STUDY_INDUSTRIES,
}

// Detailed pages first (they are the indexable, conversion-focused assets),
// followed by the earlier PDF case studies.
const allStudies = [
  ...detailedStudies.map((s, i) => ({
    id: `detail-${s.slug}`,
    href: `/case-studies/${s.slug}`,
    title: s.title,
    client: s.client,
    industry: s.industry,
    serviceId: s.service,
    service: CASE_STUDY_SERVICES[s.service].label,
    challenge: s.summary,
    outcomes: [`${s.facts[0].value} · ${s.facts[0].label}`],
    featured: i < 2,
  })),
  ...legacyStudies.map((s) => ({
    ...s,
    id: `pdf-${s.id}`,
    serviceId: LEGACY_SERVICE_IDS[s.service] || 'market-research',
    featured: false,
  })),
]

const countBy = (key) =>
  allStudies.reduce((acc, s) => {
    acc[s[key]] = (acc[s[key]] || 0) + 1
    return acc
  }, {})

const industryCounts = countBy('industry')
const serviceCounts = countBy('serviceId')

const industries = [
  { id: 'all', label: 'All industries', count: allStudies.length },
  ...Object.keys(industryCounts).map((id) => ({ id, label: industryLabels[id] || id, count: industryCounts[id] })),
]

const serviceFilters = [
  { id: 'all', label: 'All services', count: allStudies.length },
  ...Object.keys(serviceCounts).map((id) => ({
    id,
    label: CASE_STUDY_SERVICES[id]?.label || id,
    count: serviceCounts[id],
  })),
]

// Renders an internal link for detailed pages and a PDF link for the older ones.
function StudyLink({ study, className, children, ...rest }) {
  if (study.href) {
    return (
      <Link href={study.href} className={className} {...rest}>
        {children}
      </Link>
    )
  }
  return (
    <a
      href={study.pdfPath ?? '#'}
      target={study.pdfPath ? '_blank' : undefined}
      rel={study.pdfPath ? 'noopener noreferrer' : undefined}
      className={className}
      {...rest}
    >
      {children}
    </a>
  )
}

function StudyImage({ study, className }) {
  if (study.image) return <img src={study.image} alt={study.title} className={className} />
  return (
    <div
      role="img"
      aria-label={study.title}
      className="w-full h-full bg-gradient-to-br from-[#1D342F] via-[#2a4a43] to-[#4E9141] flex items-end p-6"
    >
      <span className="text-white/80 font-semibold text-sm uppercase tracking-wider">
        {industryLabels[study.industry] || study.industry}
      </span>
    </div>
  )
}

const stats = [
  { value: '500+', label: 'Projects Delivered', icon: Award },
  { value: '30+', label: 'Industries Served', icon: Building2 },
  { value: '98%', label: 'Success Rate', icon: Target },
  { value: '3x', label: 'Avg. Client ROI', icon: TrendingUp },
]

const process = [
  { num: '01', title: 'Discovery', desc: 'Deep dive into your business challenges and objectives' },
  { num: '02', title: 'Research', desc: 'Comprehensive data collection and market analysis' },
  { num: '03', title: 'Strategy', desc: 'Develop actionable recommendations and roadmap' },
  { num: '04', title: 'Implementation', desc: 'Support execution and measure outcomes' },
]

export default function CaseStudiesPage() {
  const [activeIndustry, setActiveIndustry] = useState('all')
  const [activeService, setActiveService] = useState('all')
  const [visibleCards, setVisibleCards] = useState({})

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleCards(prev => ({ ...prev, [entry.target.dataset.index]: true }))
          }
        })
      },
      { threshold: 0.1 }
    )

    document.querySelectorAll('[data-index]').forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [activeIndustry, activeService])

  const filteredStudies = allStudies.filter(study =>
    (activeIndustry === 'all' || study.industry === activeIndustry) &&
    (activeService === 'all' || study.serviceId === activeService)
  )

  const featuredStudies = allStudies.filter(s => s.featured)

  return (
    <div className="bg-[#F0F4F0] min-h-screen" data-testid="case-studies-page">

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-white border-b border-[#C2DDB4]/30 overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#4E9141]/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#C2DDB4]/20 rounded-full blur-[120px]" />

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-3 px-4 py-2 bg-[#F7FFF5] rounded-full border border-[#C2DDB4]/50 mb-8">
                <Lightbulb className="w-4 h-4 text-[#4E9141]" />
                <span className="text-[#4E9141] font-medium text-sm">Client Success Stories</span>
              </div>

              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-[#1D342F] leading-[1.1] mb-6">
                Real Results,
                <span className="text-[#4E9141]"> Real Impact</span>
              </h1>

              <p className="text-[#47635D] text-lg leading-relaxed mb-10 max-w-lg">
                From challenge to triumph  discover how we deliver measurable business impact through data-driven insights and strategic expertise.
              </p>

              <div className="flex flex-wrap gap-4">
                <a href="#cases" className="group px-8 py-4 bg-[#4E9141] text-white rounded-full font-semibold hover:bg-[#3d7334] transition-all flex items-center gap-2">
                  Explore Cases
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </a>
                <Link href="/contact-us" className="px-8 py-4 border-2 border-[#C2DDB4] text-[#1D342F] rounded-full font-semibold hover:border-[#4E9141] hover:text-[#4E9141] transition-all">
                  Start Your Project
                </Link>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-5">
              {stats.map((stat, i) => (
                <div 
                  key={i}
                  className="group bg-white border-2 border-[#C2DDB4]/40 rounded-2xl p-6 hover:border-[#4E9141] hover:shadow-lg transition-all duration-300"
                >
                  <div className="w-12 h-12 bg-[#F7FFF5] rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#4E9141]/10 transition-colors">
                    <stat.icon className="w-6 h-6 text-[#4E9141]" />
                  </div>
                  <div className="text-3xl lg:text-4xl font-bold text-[#4E9141] mb-1">{stat.value}</div>
                  <div className="text-[#47635D] text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Case Studies */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div>
              <span className="text-[#4E9141] font-medium uppercase tracking-wider text-sm">Featured</span>
              <h2 className="text-3xl font-bold text-[#1D342F] mt-2">Highlighted Success Stories</h2>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {featuredStudies.map((study) => (
              <StudyLink
                key={study.id}
                study={study}
                className="group block bg-white rounded-2xl overflow-hidden border-2 border-[#C2DDB4]/40 hover:border-[#4E9141] shadow-sm hover:shadow-xl transition-all duration-500"
              >
                {/* Image */}
                <div className="relative aspect-[16/10] overflow-hidden">
                  <StudyImage
                    study={study}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1D342F]/70 via-transparent to-transparent" />
                  
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="px-4 py-1.5 bg-[#4E9141] text-white text-sm font-semibold rounded-full shadow-md">
                      Featured
                    </span>
                    <span className="px-4 py-1.5 bg-white text-[#4E9141] text-sm font-semibold rounded-full shadow-md capitalize">
                      {industryLabels[study.industry] || study.industry}
                    </span>
                  </div>

                  <div className="absolute top-4 right-4 w-12 h-12 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-lg">
                    <ArrowUpRight className="w-5 h-5 text-[#4E9141]" />
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <p className="text-[#C2DDB4] font-medium mb-1">{study.client}</p>
                    <h3 className="text-xl lg:text-2xl font-bold text-white leading-tight">
                      {study.title}
                    </h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <p className="text-[#47635D] mb-6">{study.challenge}</p>
                  
                  <div className="flex flex-wrap gap-3">
                    {study.outcomes.map((outcome, j) => (
                      <div key={j} className="flex items-center gap-2 px-4 py-2 bg-[#F7FFF5] rounded-full border border-[#C2DDB4]/50">
                        <CheckCircle2 className="w-4 h-4 text-[#4E9141]" />
                        <span className="text-[#1D342F] text-sm font-medium">{outcome}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </StudyLink>
            ))}
          </div>
        </div>
      </section>

      {/* Filter Bar: by industry and by service */}
      <section id="cases" className="py-6 bg-white border-y border-[#C2DDB4]/30 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 space-y-3">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#47635D] mr-2">Industry</span>
            {industries.map((ind) => (
              <button
                key={ind.id}
                onClick={() => setActiveIndustry(ind.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                  activeIndustry === ind.id
                    ? 'bg-[#4E9141] text-white shadow-md shadow-[#4E9141]/20'
                    : 'bg-[#F7FFF5] text-[#47635D] hover:bg-[#C2DDB4]/30 border border-[#C2DDB4]/50'
                }`}
                data-testid={`filter-${ind.id}`}
              >
                {ind.label}
                <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                  activeIndustry === ind.id ? 'bg-white/20' : 'bg-white'
                }`}>
                  {ind.count}
                </span>
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#47635D] mr-2">Service</span>
            {serviceFilters.map((svc) => (
              <button
                key={svc.id}
                onClick={() => setActiveService(svc.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                  activeService === svc.id
                    ? 'bg-[#1D342F] text-white shadow-md'
                    : 'bg-white text-[#47635D] hover:bg-[#C2DDB4]/30 border border-[#C2DDB4]/50'
                }`}
                data-testid={`filter-service-${svc.id}`}
              >
                {svc.label}
                <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                  activeService === svc.id ? 'bg-white/20' : 'bg-[#F7FFF5]'
                }`}>
                  {svc.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-2xl font-bold text-[#1D342F]">All Case Studies</h2>
            <p className="text-[#47635D]">
              Showing <span className="font-semibold text-[#1D342F]">{filteredStudies.length}</span> case studies
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStudies.map((study, i) => (
              <StudyLink
                key={study.id}
                study={study}
                data-index={i}
                className="group block"
                data-testid={`case-study-${study.id}`}
              >
                <article 
                  className={`h-full bg-white rounded-2xl overflow-hidden border-2 border-[#C2DDB4]/40 hover:border-[#4E9141] shadow-sm hover:shadow-xl transition-all duration-500 ${
                    visibleCards[i] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${i * 50}ms` }}
                >
                  {/* Image */}
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <StudyImage
                      study={study}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1.5 bg-white text-[#4E9141] text-xs font-semibold rounded-full shadow-md capitalize">
                        {industryLabels[study.industry] || study.industry}
                      </span>
                    </div>

                    <div className="absolute top-4 right-4">
                      <span className="px-3 py-1.5 bg-[#4E9141] text-white text-xs font-semibold rounded-full shadow-md">
                        {study.service}
                      </span>
                    </div>

                    <div className="absolute inset-0 bg-gradient-to-t from-[#1D342F]/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    {/* PDF indicator or Coming Soon badge */}
                    <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                      <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-lg">
                        <ArrowRight className="w-4 h-4 text-[#4E9141]" />
                        <span className="text-[#4E9141] text-xs font-semibold">
                          {study.href ? 'Read case study' : 'View PDF'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <p className="text-[#4E9141] font-semibold text-sm mb-2">{study.client}</p>

                    <h3 className="text-lg font-bold text-[#1D342F] leading-tight mb-3 group-hover:text-[#4E9141] transition-colors line-clamp-3">
                      {study.title}
                    </h3>

                    <p className="text-[#47635D] text-sm leading-relaxed mb-4 line-clamp-2">
                      {study.challenge}
                    </p>

                    <div className="flex items-center gap-2 px-4 py-2.5 bg-[#F7FFF5] rounded-xl border border-[#C2DDB4]/50">
                      <CheckCircle2 className="w-4 h-4 text-[#4E9141] flex-shrink-0" />
                      <span className="text-[#1D342F] text-sm font-medium">{study.outcomes[0]}</span>
                    </div>
                  </div>
                </article>
              </StudyLink>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white border-t border-[#C2DDB4]/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <span className="text-[#4E9141] font-medium uppercase tracking-wider text-sm">Our Approach</span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1D342F] mt-4">
              How We Deliver <span className="text-[#4E9141]">Results</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {process.map((step, i) => (
              <div key={i} className="text-center group">
                <div className="w-20 h-20 mx-auto mb-6 relative">
                  <div className="absolute inset-0 bg-[#C2DDB4] rounded-2xl rotate-6 group-hover:rotate-12 transition-transform" />
                  <div className="absolute inset-0 bg-white border-2 border-[#4E9141] rounded-2xl flex items-center justify-center">
                    <span className="text-2xl font-bold text-[#4E9141]">{step.num}</span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-[#1D342F] mb-3">{step.title}</h3>
                <p className="text-[#47635D] text-sm">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#1D342F]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
            Ready to Write Your Success Story?
          </h2>
          <p className="text-[#C2DDB4] text-lg mb-10 max-w-2xl mx-auto">
            Partner with MARC to transform your business challenges into measurable achievements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/contact-us" 
              className="inline-flex items-center justify-center gap-3 px-10 py-4 bg-[#4E9141] text-white rounded-full font-semibold hover:bg-[#5ba84d] transition-all group"
            >
              Start Your Project
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link 
              href="/insights" 
              className="inline-flex items-center justify-center gap-3 px-10 py-4 bg-white/10 text-white border border-white/20 rounded-full font-semibold hover:bg-white/20 transition-all"
            >
              View Insights
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
